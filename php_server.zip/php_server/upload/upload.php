<?php

require "../common/StringCommon.php";

function checkPostData() {
    if (!$_POST) {
        echoLine("ERROR: no post data!");
        return false;
    }
    
    $rtn = true;
    if (!$_POST['date']) {
        echoLine("ERROR: date is empty!");
        $rtn = false;
    }
    if (!$_FILES['file']['name']) {
        echoLine("ERROR: file is empty!");
        $rtn = false;
    }
    return $rtn;
}

function ensureDir($dir_path) {
    if (!file_exists($dir_path)) {
        mkdir($dir_path);
        echoLine("Create folder: $dir_path");
    }
    chmod($dir_path, 0777);
}

function ensureIndexPhp($dir_path) {
    $file_path_name = $dir_path . "index.php";
    $src_path_name = "../common/ShowImages.php";
    
    $url_this =  "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
    $link_url = "$url_this/../$file_path_name";
    if (!file_exists($file_path_name)) {
        echoLine("Create file <a href='$link_url' >$file_path_name</a>.");
        copy($src_path_name, $file_path_name);
        chmod($file_path_name, 0777);
    } else {
        echoLine("File <a href='$link_url' > $file_path_name </a> exist.");
    }
}

function isAccessableType($fileType) {
    return ($fileType == "image/gif")
        || ($fileType == "image/jpeg")
        || ($fileType == "image/pjpeg")
        || ($fileType == "image/png")
        || ($fileType == "image/x-png")
        || ($fileType == "image/webp");
}

function checkFileSize() {
    $curr_image_size = $_FILES["file"]["size"];
    $max_image_size = 20 * 1024 * 1024;
    
    if ($curr_image_size > $max_image_size) {
        $curr_in_kb = $curr_image_size / 1024;
        $max_in_kb = $max_image_size / 1024;
        echoLine("File size can not be larger than $max_in_kb KB. Current file size is $curr_in_kb KB.");
        return false;
    }
    return true;
}

function doSomeCheck() {
    if (!checkPostData()) {
        return false;
    }

    if (!isAccessableType($_FILES["file"]["type"])) {
        echoLine("Invalid file type: " . $_FILES['file']['type']);
        return false;
    }

    if (!checkFileSize()) {
        return false;
    }

    return true;
}

// Use time stamp.
function isFileExist($folderPath, $fileName, $uploadFileStamp, $uploadIndex) {
    $save_path_name = $folderPath . $fileName;
    if (file_exists($save_path_name)) {
        echoLine("$save_path_name already exists.");
        return true;
    }
    
    foreach (glob($folderPath . "*") as $a_file) {
        $saveTime = "";
        $timeStamp = "";
        $index = "";
        //echoLine("upload: $uploadFileStamp, $uploadIndex");
        if (spiltSavedFileName($a_file, $saveTime, $timeStamp, $index)) {
            //echoLine("file: $timeStamp, $index");
            if ($uploadFileStamp == $timeStamp && $uploadIndex == $index) {
                echoLine("New file '$fileName' is exist!");
                echoLine("For it has the same time stamp and index with '$a_file'.");
                return true;
            }
        }
    }
    
    return false;
}

function main() {
    if (!doSomeCheck()) {
        return;
    }
    
    if ($_FILES["file"]["error"] > 0) {
        echoLine("Return Code: " . $_FILES["file"]["error"]);
    } else {
        $file_name = $_FILES["file"]["name"];
        
        $timeStamp = "";
        $url = "";
        $index = "";
        $extName = "";
        if (!spiltUploadedFileName($file_name, $timeStamp, $url, $index, $extName)) {
            echoLine("File name: '$file_name' is not apposite!");
            echoLine("Must be like this \"1393061560638-info.3g.qq.com-1.jpg\"");
            return;
        }
        
        // for debug
        if (false) {
            echoLine(" $file_name");
            echoLine("  $timeStamp");
            echoLine("  $url");
            echoLine("  $index");
            echoLine("  $extName");
        }

        echoLine("Upload: $file_name");
        echoLine("Type: " . $_FILES['file']['type']);
        echoLine("Size: " . ($_FILES["file"]["size"] / 1024) . " Kb");
        echoLine("Temp file: " . $_FILES["file"]["tmp_name"]);

        $post_date = $_POST['date'];
		$re = $_POST['re'];
		$url =  $_POST['url'];
		$dir_name = "";
		if($re!="")
		{
		    ensureDir( "../images/sites/$re/");
			$dir_name = "../images/sites/$re/$url/";
		}
		else
		{
			$dir_name = "../images/sites/$url/";
		}
        ensureDir($dir_name);
        
        $save_file_name = "$post_date-$timeStamp-$index$extName";
        $save_path_name = $dir_name . $save_file_name;
        if (isFileExist($dir_name, $save_file_name, $timeStamp, $index)) {
            ensureIndexPhp($dir_name);
            return;
        }
    
        move_uploaded_file($_FILES["file"]["tmp_name"], $save_path_name);
        chmod($save_path_name, 0777);
        echoLine("Stored in: $save_path_name");

        ensureIndexPhp($dir_name);
    }
}

main();

?>