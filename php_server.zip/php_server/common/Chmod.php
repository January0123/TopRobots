<?php

chmod(".", 0777);
foreach (glob("./*") as $file_name) {
    echo "$file_name <br />";
    chmod($file_name, 0777);
}

?>
