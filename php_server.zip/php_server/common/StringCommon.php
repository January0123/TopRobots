<?php

function echoLine($str) {
    echo "$str <br />";
}

function echoTextLine($line) {
    echo "$line\r";
}

function isImage($file) {
    if (!is_file($file)) {
        return false;
    }
    
    if (strrpos($file, ".php")) {
        return false;
    }
    return true;
}

// the input {fileName} like this:
// "1393061560638-info.3g.qq.com-1.jpg"
// "1393061560638-info.3g.qq.com--1.jpg"
function spiltUploadedFileName($fileName, &$timeStamp, &$url, &$index, &$extName) {
    $timeEnd = strpos($fileName, "-");
    if (!$timeEnd) {
        return false;
    }
    
    $urlEnd = strrpos($fileName, "-");
    if (!$urlEnd) {
        return false;
    }
    
    $indexEnd = strrpos($fileName, ".");
    if (!$indexEnd) {
        return false;
    }
    
    if (($timeEnd >= $urlEnd) || ($urlEnd >= $indexEnd)) {
        return false;
    }
    
    $timeStamp = substr($fileName, 0, $timeEnd);
    $url = substr($fileName, $timeEnd + 1, $urlEnd - $timeEnd - 1);
    $index = substr($fileName, $urlEnd + 1, $indexEnd - $urlEnd - 1);
    $extName = substr($fileName, $indexEnd);
    
    // remove last '-'s
    $len = strlen($url);
    $i = $len - 1;
    for (; $i >= 0; --$i) {
        if ($url[$i] != '-') {
            break;
        }
    }
    $url = substr($url, 0, $i + 1);
    
    return true;
}

// the input {fileName} like this:
// "20140302133210-1393061560638-1.jpg"
function spiltSavedFileName($fileName, &$saveTime, &$timeStamp, &$index) {
    $dateTimeEnd = strpos($fileName, "-");
    if (!$dateTimeEnd) {
        return false;
    }
    
    $timeStampEnd = strrpos($fileName, "-");
    if (!$timeStampEnd) {
        return false;
    }
    
    $indexEnd = strrpos($fileName, ".");
    if (!$indexEnd) {
        return false;
    }
    
    if (($dateTimeEnd >= $timeStampEnd) || ($timeStampEnd >= $indexEnd)) {
        return false;
    }
    
    $saveTime = substr($fileName, 0, $dateTimeEnd);
    $timeStamp = substr($fileName, $dateTimeEnd + 1, $timeStampEnd - $dateTimeEnd - 1);
    $index = substr($fileName, $timeStampEnd + 1, $indexEnd - $timeStampEnd - 1);
    return true;
}

// the input {fileName} like this:
// "../images/sites/www.baidu.com/20140302133210-1393061560638-1.jpg"
function getUploadTimeFromPathName($filePathName, &$uploadTime) {
    $start = strrpos($filePathName, "/");
    if (!$start) {
        $start = 0;
    }
    
    $end = strpos($filePathName, "-", $start);
    if (!$end) {
        return false;
    }
    
    $uploadTime = substr($filePathName, $start + 1, $end - $start - 1);
    return true;
}

$gImagesInfo = null;
function getAllUploadDates($dirPath) {
    global $gImagesInfo;
    if ($gImagesInfo) {
        return $gImagesInfo;
    }
    
    $gImagesInfo = array();
    foreach (glob($dirPath) as $fileName) {
        if (!isImage($fileName)) {
            continue;
        }
        
        $uploadTime = "";
        if (!getUploadTimeFromPathName($fileName, $uploadTime)) {
            continue;
        }
        
        if (!array_key_exists($uploadTime, $gImagesInfo)) {
            $gImagesInfo[$uploadTime] = 0;
        }
        $gImagesInfo[$uploadTime] += 1;
        //echoLine($uploadTime);
        //echoLine($gImagesInfo[$uploadTime]);
    }
    ksort($gImagesInfo);
    return $gImagesInfo;
}
