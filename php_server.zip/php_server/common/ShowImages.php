<html>
<head>
<meta charset="UTF-8">
</head>
<body>

<?php
function echoLine($line) {
    echo "$line<br/>";
}

// show current folder
echoLine("Dir: " . getcwd());
?>

<br />
<div>
<input type="radio"  value="list" name="display" onchange = "viewChanged();" >显示列表</input>
<input type="radio" checked value="image" name="display" onchange = "viewChanged();">显示图片</input>
</div>

<div id="container">
    <div id="list-view">
        <hr>
        <style>
            th { padding: 2px 8px 2px 8px; }
            td a { padding-right: 20px; }
        </style>
        <table style='text-align: left;' id="image-list">
            <tr><th>File</th><th>Last Modify time</th></tr>
        </table>
        <tr><hr></tr>
    </div>

    <style>
        .image-files {
            background-color: #faa;
        }
        
        #images td {
            vertical-align: top;
            text-align:left;
        }
        
        #images td img {
            border: 1px solid #f00;
        }
    </style>
    <div id="image-view">
        <hr>
        <table>
            <tr id = "time-stamp"> </tr>
            <tr id = "images"> </tr>
        </table>
        <hr>
    </div>
</div>

<?php
function isImage($file) {
    if (!is_file($file)) {
        return false;
    }
    
    if (strrpos($file, ".php")) {
        return false;
    }
    return true;
}

// get image file names and their last modify time.
function getImagesInfo($dirPath) {
    $imagesInfo = array();
    foreach (glob($dirPath) as $fileName) {
        if (isImage($fileName)) {
            $imagesInfo[$fileName] = date('Y-m-d H:i:s', filemtime($fileName));
            //echoLine($fileName);
            //echoLine($imagesInfo[$fileName]);
        }
    }
    return $imagesInfo;
}

// the input {fileName} like this:
// "20140302133210-1393061560638-1.jpg"
function spiltSavedFileName($fileName, &$saveTime, &$timeStamp, &$index) {
    $dateTimeEnd = strpos($fileName, "-");
    if (!$dateTimeEnd) {
        return false;
    }
    
    $timeStampEnd = strrpos($fileName, "-");
    if (!$timeStampEnd) {
        return false;
    }
    
    $indexEnd = strrpos($fileName, ".");
    if (!$indexEnd) {
        return false;
    }
    
    if (($dateTimeEnd >= $timeStampEnd) || ($timeStampEnd >= $indexEnd)) {
        return false;
    }
    
    $saveTime = substr($fileName, 0, $dateTimeEnd);
    $timeStamp = substr($fileName, $dateTimeEnd + 1, $timeStampEnd - $dateTimeEnd - 1);
    $index = substr($fileName, $timeStampEnd + 1, $indexEnd - $timeStampEnd - 1);
    return true;
}

function getJSImageVectorString() {
    $root_dir = "*";
    $imageInfos = getImagesInfo($root_dir);
    
    $count = 0;
    $fileNames = "var gFileNames = [";
    $lastModifyTimes = "var gLastModifyTimes = [";
    $uploadTimes = "var gUploadTimes = [";
    $saveTimeStamps = "var gSaveTimeStamps = [";
    
    foreach ($imageInfos as $key => $value) {
        if ($count++ > 0) {
            $fileNames = $fileNames . ", ";
            $lastModifyTimes = $lastModifyTimes . ", ";
            $uploadTimes = $uploadTimes . ", ";
            $saveTimeStamps = $saveTimeStamps . ", ";
        }
        $key = iconv("gb2312", "utf-8", $key);
        $fileNames = $fileNames . "\"$key\"";
        $lastModifyTimes = $lastModifyTimes . "\"$value\"";
        
        $uploadTime = "";
        $timeStamp = "";
        $index = "";
        if (spiltSavedFileName($key, $uploadTime, $timeStamp, $index)) {
            $uploadTimes = $uploadTimes . "\"$uploadTime\"";
            $saveTimeStamps = $saveTimeStamps . "\"$timeStamp\"";
        }
    }
    $fileNames = $fileNames . "];";
    $lastModifyTimes = $lastModifyTimes . "];";
    $uploadTimes = $uploadTimes . "];";
    $saveTimeStamps = $saveTimeStamps . "];";
    
    $jsString = "<script>" . $fileNames . $lastModifyTimes . $uploadTimes . $saveTimeStamps . "</script>";
    return $jsString;
}

// write images info into JS var gImageInfos.
echoLine(getJSImageVectorString());

?>

<script>
function writeImageList() {
    var table = document.getElementById("image-list");
    for (var i = 0; i < gFileNames.length; ++i) {
        var obj = document.createElement("tr");
        obj.innerHTML = "<td><a href='" + gFileNames[i] + "'>"+ gFileNames[i] + 
            "</a></td> <td>" + gLastModifyTimes[i] + "</td>";
        table.appendChild(obj);
    }
    
    var obj = document.createElement("div");
    obj.innerHTML = "Image count: " + gFileNames.length + ".";
    document.getElementById("list-view").appendChild(obj);
}

function writeImageView() {
    var timeStamp = document.getElementById("time-stamp");
    var images = document.getElementById("images");
    for (var i = 0; i < gSaveTimeStamps.length; ++i) {
        var obj = document.getElementById("t" + gSaveTimeStamps[i]);
        if (!obj) {
            obj = document.createElement("th");
            obj.innerHTML = "" + gSaveTimeStamps[i] + " <a href='#'>(TODO:设为Baseline)</a>";
            timeStamp.appendChild(obj);
            
            obj = document.createElement("td");
            obj.id = "t" + gSaveTimeStamps[i];
            images.appendChild(obj);
        }
    }
    
    for (var i = 0; i < gFileNames.length; ++i) {
        var obj = document.getElementById("t" + gSaveTimeStamps[i]);
        obj.innerHTML += "<div class='image-files'>" + gFileNames[i] + "</div> <div><a href=\"" + gFileNames[i] + "\"><img src='" + gFileNames[i] + "'></a></div>";
    }
    
    var obj = document.createElement("div");
    obj.innerHTML = "Image count: " + gFileNames.length + ".";
    document.getElementById("image-view").appendChild(obj);
}

function viewChanged() {
    var radio = document.getElementsByName("display");
    if (radio[0].checked) {
        document.getElementById("list-view").style.display = "";
        document.getElementById("image-view").style.display = "none";
    } else if (radio[1].checked) {
        document.getElementById("list-view").style.display = "none";
        document.getElementById("image-view").style.display = "";
    }
}

viewChanged();
writeImageList();
writeImageView();

</script>

</body>
</html>