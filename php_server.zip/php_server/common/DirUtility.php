<?php

function writeRow($item) {
    echo "<tr>";
    $only_folder = $item;
    $last_pot = strrpos($only_folder, DIRECTORY_SEPARATOR);
    if ($last_pot) {
        $only_folder = substr($only_folder, $last_pot + 1);
    }
    echo "<th><div><a href='$item'>" . $only_folder . "</a></div></th>";
    echo "<th>" . date('Y-m-d H:i:s', filemtime($item)) . "</th>";
            echo "</tr>";
}

function isDailyFolder($folder) {
    return is_dir($folder) && 
           (file_exists($folder . "/index.php") ||
            file_exists($folder . "/index.html") ||
            file_exists($folder . "/index.htm"));
}

function countDirs($path) {
    $count = 0;
    foreach (glob($path) as $folder) {
        if (isDailyFolder($folder)) {
            ++$count;
        }
    }
    return $count;
}

function showPagesIndex($path, $countPerPage, $currPage, $folderCount,$g_imagePath) {
    $pageCount = ceil($folderCount / $countPerPage);
    echo "Page Index: ";
    for ($i = 0; $i < $pageCount; ++$i) {
        $displayIndex = $i + 1;
        echo " <a href='index.php?re=$g_imagePath&index=$i&count=$countPerPage'>";
        if ($i == $currPage) {
            echo "<b style='color:#00f;'>$displayIndex</b>";
        } else {
            echo "$displayIndex";
        }
        echo "</a> ";
    }
}

function displayPage($path, $disply_text, $pageIndex, $countPerPage,$g_imagePath) {
    echo "dir: <b>$disply_text</b>";
    echo "<br /><br />";
    
    $folderCount = countDirs($path);
    showPagesIndex($path, $countPerPage, $pageIndex, $folderCount,$g_imagePath);
    echoLine(" ");
    echoLine(" ");
    
    echo "<style>th { padding: 2px 8px 2px 8px; }</style>";
    echo "<hr><table style='text-align: left;'>";
    echo "<tr><th>Folder</th><th>Last Modify time</th></tr>";
    
    $start = $pageIndex * $countPerPage;
    $end = $start + $countPerPage;
    $offset = 0;
    foreach (glob($path) as $folder) {
        if (!isDailyFolder($folder)) {
            continue;
        }
        if ($offset >= $start && $offset < $end) {
            writeRow($folder);
        }
        if (++$offset >= $end) {
            break;
        }
    }
    echo "</table>";
    echo "<tr><hr></tr>";
    
    echoLine(" ");
    showPagesIndex($path, $countPerPage, $pageIndex, $folderCount,$g_imagePath);
    echo "<br /><br />";
    echo "All sites count: " . $folderCount . ".  ";
}
