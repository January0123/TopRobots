<?php

require "DirUtility.php";
require "StringCommon.php";


	$g_imagesRootFolder = "images/sites/*";

function showImageFolders($pageIndex, $countPerPage,$g_imagePath) {
    global $g_imagesRootFolder;
    
	if($g_imagePath!="")
	{
		$g_imagesRootFolder = "images/sites/".$g_imagePath."/*";
	}
	else{
		$g_imagesRootFolder = "images/sites/*";
	}
    $searchDir = $g_imagesRootFolder;
    $display_path = getcwd() . "/" . $searchDir;
    
    if (DIRECTORY_SEPARATOR != "/") {
        $searchDir = str_replace("/", DIRECTORY_SEPARATOR, $searchDir);
        $display_path = str_replace("/", DIRECTORY_SEPARATOR, $display_path);
    }

    displayPage($searchDir, $display_path, $pageIndex, $countPerPage,$g_imagePath);
}
